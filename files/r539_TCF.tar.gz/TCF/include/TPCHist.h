////////////////////////////TCF/////////////////////////////
// TPC Coherent Fit (TCF)                                 //
// Author: Xianguo Lu, lu.xianguo@gmail.com               //
// Reference: Xianguo Lu, "Exploring the performance      //
// limits of the ALICE Time Projection Chamber and        //
// Transition Radiation Detector for measuring identified //
// hadron production at the LHC", dissertation at the     //
// University of Heidelberg (2013).                       //
////////////////////////////////////////////////////////////

#ifndef _TPCHIST_H_
#define _TPCHIST_H_

#include "headers.hh"

//===================================================================================
//  Defining histogram as input for the TCF.
//  see descriptions in 
//      TPCHist::TPCHist(const TH2D *horiginal)
//      TPCHist::Ini
/*
//test

dir=tmp_anchor4_YB2_XB7
mkdir $dir
cd $dir
cp $TCF_PATH/lib/lib*.so .
cp $TCF_PATH/data/LHC10dMC_RAA_ETA3/hist.root .
root -l hist.root

gSystem->Load("libBaseUtils.so")
gSystem->Load("libTPCHist.so")

hh=horiginal
//new TCanvas; hh->Draw("colz"); gStyle->SetOptStat("enoum"); gPad->SetLogz()

TH2D * hfitdata=0x0
TH2D * hprefilter=0x0
TH2D * hrest=0x0
TH1D * hrawyield = 0x0
TH1D * hfityield = 0x0

h1=(TH2D*)hh->Clone("h1")

TPCHist obj(h1);

hrest = obj.GetFitData(hfitdata, hrawyield, hprefilter, hfityield, 1);
new TCanvas; hfitdata->Draw("colz"); gStyle->SetOptStat("enoum"); gPad->SetLogz()
new TCanvas; hprefilter->Draw("colz"); gStyle->SetOptStat("enoum"); gPad->SetLogz()
new TCanvas; hrest->Draw("colz"); gStyle->SetOptStat("enoum"); gPad->SetLogz()
new TCanvas; hrawyield->Draw(); gStyle->SetOptStat("enoum"); gPad->SetLogy()
new TCanvas; hfityield->Draw(); gStyle->SetOptStat("enoum"); gPad->SetLogy()

*/
//===================================================================================

class TPCHist
{
 public:
  TPCHist(){}
  TPCHist(const TH2D *horiginal);
  virtual ~TPCHist(){}

  //print all settings
  void Print();
  
  TH2D* GetFitData(TH2D *& hfitdata, TH1D *& hrawyield, TH2D *& hprefilter, TH1D *& hfityield, const Bool_t krest);

  static Bool_t FilterIX(const TH2D * hh, const Int_t ix);
  static Double_t Y1(){return 198;} //180;}
  static Double_t Xmid(){return TMath::Log10(4); } //xx=6.02e-01 where the relativistic rise starts

  Int_t Xrebin(){return fXrebin;}
  Double_t AnchorN(){return fAnchorN;}

 private:
  void Ini(const TH2D *horiginal, const Int_t xrebin, const Int_t yrebin, const Double_t anchorN, const Int_t ancopt);
  
  static Double_t PbinThres(){return 50;}

  static Double_t X0(){return fX0;} //return -0.2;} //p=6.3e-01
  static Double_t X1(){return fX1;}//1e9;}
  static Double_t Y0(){return 20;}

  //========

  const TH2D * fHist;

  static Double_t fX0;
  static Double_t fX1;
  Int_t fXrebin;
  Int_t fYrebin;
  Double_t fAnchorN;
  Int_t fAncOpt;

  ClassDef(TPCHist,3);
};

#endif
