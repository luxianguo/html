#drawpar on coherent fit output

if [ $TCF_PATH\kk == kk ]
then
    echo "TCF_PATH not set! do"
    echo "source source.sh"
    exit
fi

dsets=$(echo $(pwd)/*/X*/coherentFit)

dd0=$(pwd)

#GSI
absd=$TCF_PATH/SysUtils
predo="export ROOTSYS=$ROOTSYS; cd $TCF_PATH; source ./source.sh; cd -;"

echo $predo

################################

kqsub=1

###################################

execdir=dummy

if [ $kqsub == 1 ]
then
    execdir=execqsub
else
    execdir=execlocal
fi

################################

for ii in $dsets
do 
#    echo $ii
    cd $ii
    pwd

###
    for ff in $(echo drawpar dodrawpar.sh drawpar.C subdo.sh *sh.e* *sh.o*)
    do
        if [ -e $ff ]
        then
            unlink $ff
        fi
    done

    rm -f *parmn2d*Beta*.root
    rm -f seedrawpar_outmn2d*.log

###

    mkdir -p $execdir
    cd $execdir     

#have to copy, farm does not see /u/
    for ff in $(echo drawpar dodrawpar.sh drawpar.C)
    do
        if [ -e $ff ]
        then
            unlink $ff
        fi

        cp $absd/$ff .
    done

    rm -f *parmn2d*Beta*.root
    rm -f seedrawpar_outmn2d*.log

    cat > subdo.sh <<EOF
#!/bin/sh
                                                                                                                                                                       
uname -a

$predo

cd $(pwd)

echo ls
ls
echo

echo pwd
pwd
echo

export PATH=$(pwd)/:$PATH

echo go

./dodrawpar.sh

EOF

    chmod +x ./dodrawpar.sh; 
    chmod +x subdo.sh

    if [ $kqsub == 1 ]
    then
        qsub -P alice -cwd -l h_rt=1:0:0,h_rss=2G  ./subdo.sh     
    else
        ./dodrawpar.sh 
    fi

    #/alidata60/alice_u/lu/workspace/myutils/bin/subcondor.sh subdo.sh

    cd $dd0

done
