
if [ $TCF_PATH\kk == kk ]
then
    echo "TCF_PATH not set! do"
    echo "source source.sh"
    exit
fi



#################################################################
#getGrSys on drawpar output
#used also for TOF cases

dd0=$(pwd)

absd=$TCF_PATH/SysUtils
predo="export ROOTSYS=$ROOTSYS; cd $TCF_PATH; source ./source.sh; cd -;"

exec=execqsub

#################################################################

#no fit, beta11
#kCheckCp=0
#real fit, beta22
kCheckCp=1

###############################################################

#normal
for ii in $(echo DAT*)

#test mean sigma
#for ii in $(echo DAT*JPT{5-10,10-15,15-20}*)
  do



###############################################################      

#check!!
#should include also bad* which are to be rejected by setbadid in getGrSys        

#full, cmpTPC
files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep Beta22  | grep _rb1 | grep khm0 "


#beta11
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep Beta11  | grep _rb1 | grep khm0 "

#cmpXmin
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep Beta11  | grep _rb1 | grep khm0 | grep ancopt1 "
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep Beta22  | grep _rb1 | grep khm0 "

###########################################################

#all IDs
#for grid in $(echo {1,6,2,3,7,8}{0,3} 0{1,2}  )
#discard xi
for grid in $(echo {1,6,2,7}{0,3} 0{1,2}  )

#cmpXmin,cmpBeta11
#for grid in $(echo 10 )

#cmpTPC
#for grid in $(echo {1,6}0 0{1,2} )

#fast ID 
#for grid in $(echo {1,6,2,7}0 )
#for grid in $(echo 10 )
#for grid in $(echo {1,6,2,7}{0,3} )
#pure MC
#for grid in $(echo {6,7}{0,3} )


####

#test MC, with TOF
#for grid in $(echo {1,6,2,3,7,8,9}{0,3} {0,5}8  )

#test mean
#for grid in $(echo 10 {0,5}{1,2} )

#################################################################

    do 
        dir=$dd0/$ii/Sys$grid
        echo $dir
        mkdir -p $dir
        cd $dir

        cat > subgetgr.sh <<EOF
#!/bin/sh

uname -a

$predo

cd $dir

echo ls
ls
echo

echo pwd
pwd
echo

                                                                                                                                                         
export PATH=$(pwd)/:$PATH
                         
echo go

rm -f in.log

ksetbad=1

if [ ${grid:0:1} == 0 -o ${grid:0:1} == 5  ]
then

grep accept ../Sys10/see10.log | awk '{print \$7}' | grep XB5   > in.log 
ksetbad=0

#$files | grep XB5 > in.log      

else

$files > in.log

fi
            
wc in.log
            
$absd/getGrSys in.log $grid \$ksetbad $kCheckCp > see$grid.log

EOF

        chmod +x ./subgetgr.sh;    
        qsub -P alice -cwd -l h_rt=1:0:0,h_rss=1G  ./subgetgr.sh
        #./subgetgr.sh
        cd -


    done

done


