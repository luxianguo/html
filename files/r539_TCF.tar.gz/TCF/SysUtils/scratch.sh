1. test/DATA/link.sh
    edit test/dojob.sh
    jobmonitor.sh
    run test/dojob.sh

1.1 check executed jobs

ver=t31

 for pp in $(find DATA*/*histRecTHnI*/co*$ver/X*/hist.root ); do ii=$(dirname $pp);  jj=$(grep "1: hist.root" $ii/coh*/see.log |wc| awk '{print $1}'); echo $ii $jj ;done > seehead.log

ate; tt=0; ss=0; for ii in $(seq 0 1); do jj=$(cat seehead.log | awk '{if($2=='$ii')print}' |wc | awk '{print $1}'); tt=$( expr $tt + $jj); ss=$(echo $ii $jj $ss | awk '{print $1*$2+$3}'); echo $ii $jj $tt $ss; done > seehead01.log
Di 10. Jun 22:48:03 CEST 2014

 cat seehead01.log

1.2 move fit output

gg=$ver\finish

mkdir $gg/TPC1TOF9

for mm in $(echo $gg/TPC*); do aa=$(basename $mm); for kk in $(echo DATA/histRecTHnI*$aa\*/coh*$ver | tr -s ' ' '\n'); do pp=$(echo $kk | tr -s '/' '_');  dir=$gg/$aa/$pp; mv $kk $dir; done; done

cd $gg

for pp in $(find TPC*/*histRecTHnI*co*/X*/hist.
root ); do ii=$(dirname $pp);  jj=$(grep "mn2d done" $ii/coh*/see.log |wc| awk '{print $1}'); echo $ii $jj ;done > seemn2ddone.log


date; tt=0; ss=0; for ii in $(seq 0 1); do jj=$(cat seemn2ddone.log | awk '{if($2=='$ii')print}' |wc | awk '{print $1}'); tt=$( expr $tt + $jj); ss=$(echo $ii $jj $ss | awk '{print $1*$2+$3}'); echo $ii $jj $tt $ss; done > seemn2ddone01.log

wc $(cat seemn2ddone.log | awk '{if($2==0) print $1"/co*/see.log"}') | sort -n > see0log.log
head see0log.log

for ii in  $(cat seemn2ddone.log | awk '{if($2==0) print $1"/co*/see.log"}'); do echo $ii; tail -n 2 $ii; echo; done > see0tail.log
cat see0tail.log

#
 bbs=$(echo 11{2,3,4,5,6,7,8} 22{1,2,3,4,5,6,7,8,9} 230)

for ii in $(echo $bbs); do echo $ii;  find TPC*/*coher*/X*/co*/outmn2d*
kHESSE1_fkErr0*Beta$ii* > seeErr0Beta$ii\.log; find TPC*/*coher*/X*/co*//outmn2d*kHESSE1_fkErr4*Beta$ii* > seeErr4Beta$ii\.log; done

for ii in $(echo $bbs); do wc seeErr*Beta$ii*; echo;  done

wc seeErr*Beta11* | grep -v " 0 "

wc seeErr*Beta22* | grep -v " 0 "



1.3 convert results (go to SysUtils/ and compile.sh)
cat > tmpdo.sh <<EOF
EOF

if [ $TCF_PATH\kk == kk ]
then
    echo "TCF_PATH not set! do"
    echo "source source.sh"
    exit
fi

rm -f nohup.out
nohup $TCF_PATH/SysUtils/subdrawpar.sh &
EOF
chmod +x tmpdo.sh

 for ii in $(echo TPC*); do echo $ii; cd $ii;   ../tmpdo.sh; cd -;done

1.4 check drawpar output

RB=1
KHM=

exec=execqsub

#should be number of all submitted jobs
for ii in $(echo TPC*/*coher*/X*/co*/$exec/seedra*rb$RB*khm$KHM*.log); do jj=$(grep drawpardone $ii |wc| awk '{print $1}'); echo $ii $jj; done  > seealldrawpardone.log


grep -v "*" seealldrawpardone.log  |wc

#should show nothing, unless too sparse entries so that there is missing point in the graph and hence failing drarpar
cat seealldrawpardone.log | awk '{if($2==0) print }'

target=$(echo 22) # 11) #
bbs=$(echo $target)
for ii in $(echo $bbs); do  find TPC*/*coher*/X*/co*/$exec/*parmn2d*Beta$ii*rb$RB*khm$KHM*.root > seegoodBeta$ii\.log ; done


#Err0+Err4=mn2d01
#Beta101 > 201 > 202 > 301 > 302 = mn2d01
#good+bad12 = Err0 in case all drawpar done
for ii in $(echo $bbs); do wc see*Err*Beta$ii*;   wc see*good*Beta$ii* ; echo; done


#should = drawpar done
grep  -v "*"  seealldrawpardone.log | awk '{if($2!=0) print}' | grep $target |wc

#due to HyperMatrix, the number of (good+bad) = 2 * Err0
wc seegoodBeta*$target*

wc seeErr0Beta22*

wc seeErr*Beta22*
cat seemn2ddone01.log

#if not zero, check and possibly need to resubmit
cat seealldrawpardone.log | awk '{if($2==0) print }' |wc

1.5

rm -rf TPC*/*/*Sys*

cat > tmpdo.sh <<EOF
EOF

if [ $TCF_PATH\kk == kk ]
then
    echo "TCF_PATH not set! do"
    echo "source source.sh"
    exit
fi

rm -f nohup.out
nohup $TCF_PATH/SysUtils/jobgetGrSys.sh &
EOF
chmod +x tmpdo.sh

 for ii in $(echo TPC*); do echo $ii; cd $ii;   ../tmpdo.sh; cd -;done


sleep 3

tail -f TPC*/nohup*

1.6

ids=$(echo  {1,2}{0,3} )
for id in $(echo $ids);do for ii in $(echo TPC*/*/Sys$id/see*.log); do jj=$(grep getGrSysdone $ii  |wc); echo $ii $jj ; done; done> seeGrSysdone.log
cat seeGrSysdone.log | awk '{if($2==0) print}' | grep Sys10

for id in $(echo $ids); do echo $id; grep acceptedfraction TPC*/*/Sys$id/see*.log; echo; done > seeGrSysFractions.log
cat seeGrSysFractions.log | grep Sys10 | awk '{if($4 <0.5 ) print}' | sort -n -k 4

for grid in $(echo $ids ); do  wc  TPC*/*/Sys$grid/in.log  | sort -n > seein$grid\.log; done

for grid in $(echo $ids ); do  jj=$( grep getGrSysdone TPC*/*/Sys$grid/see$grid\.log | wc); echo $jj $grid; done | sort -n > seeout.log;
cat seeout*

cat seein10.log

wc see*Beta22.log


