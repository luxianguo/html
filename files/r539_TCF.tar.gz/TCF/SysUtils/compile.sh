TCF_exe_mk.sh drawpar
