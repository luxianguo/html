if [ $TCF_PATH\kk == kk ]
then
    echo TCF_PATH empty! 
    echo source source.sh
    exit
fi

cd TTreeStream; TCF_lib_mk.sh  TTreeStream ; cd -

cd src; 

for ii in $(echo BaseUtils TPCHist dEdxGausN MN2D)
do
    TCF_lib_mk.sh $ii
done

for ii in $(echo fith mn2d genhist)
do
    TCF_exe_mk.sh $ii
done

cd -

cd plot
TCF_exe_mk.sh readiBeta
cd -

echo $0" done!"


