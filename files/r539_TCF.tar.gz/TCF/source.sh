if [ $ROOTSYS\kk == kk ]
then
    echo "ROOTSYS empty!"
    echo
    return
fi

export TCF_PATH=$(pwd)
export LD_LIBRARY_PATH=$ROOTSYS/lib:$TCF_PATH/lib:$LD_LIBRARY_PATH
export PATH=$ROOTSYS/bin:$TCF_PATH/bin:$TCF_PATH/plot:$PATH

echo
echo "************************************************************"
echo "*            TCP Coherent Fit (TCF) initialized!           *"  
echo "*            ROOTSYS="$ROOTSYS                     
echo "*            TCF_PATH="$TCF_PATH
echo "*            Now do (if haven't done yet)                  *"
echo "*            ./install.sh                                  *"
echo "*            to compile all macros                         *"
echo "************************************************************"
echo


