
if [ $TCF_PATH\kk == kk ]
then
    echo TCF_PATH not set!! source.sh not sourced!
    exit
fi

cat > rootsys.sh<<EOF
export ROOTSYS=$ROOTSYS
EOF

dd0=$(pwd)

########################################################################
#before any loop!!
counter=0
########################################################################

for tag in $(echo IDFF )
#Incl)
  do

kmc=
#dsets="$(find $(pwd)/DATA/histRec*$tag*kMC$kmc* -type l | grep TPC1TOF2 )  $(find $(pwd)/DATA/histRec*$tag*kMC$kmc* -type l | grep TPC1TOF4)"
#dsets="$(find $(pwd)/DATA/histRec*$tag*kMC$kmc* -type l | grep TPC1 )"
dsets="$(find $(pwd)/DATA/histRec*$tag*kMC$kmc* -type d | grep TPC1 )"

#dsets=$(find $(pwd)/DATA/Toy1 -type d | grep -v svn | grep -v /coh )

echo $tag
echo $dsets | tr -s ' ' '\n' 
echo $dsets | tr -s ' ' '\n' |wc
echo

#enable to check number of files
#continue

jobid=t31

########################################################################
#                       controls in dEdxGausN
########################################################################

#control of log10p rebin
xbs=$(echo 7 5)

#control of TPC signal rebin
ybs=$(echo  2 3)
#

x0s=$(echo -9 )
#-9 ) ###################################### NO NEED TO CHANGE

x1s=$(echo 40 )

#BetheBloch parametrization
#lund, aleph and mBB is equivalent; mBB is faster and is the only one possible to work with ntype = 3 (without electron)
mm=$(echo mBB lund aleph) 
#BBXing)

#weight
anchorNs=$(echo  3 2 ) ############################################### NO NEED TO CHANGE 
#4 3 ) ############################################### NO NEED TO CHANGE 
#if [ $tag == Incl ]
#    then 
#    anchorNs=$(echo 4 5)
#fi
#echo anchorNs $anchorNs
#echo

#

ancopts=$(echo 0 1)  ############################################### NO NEED TO CHANGE   

#number of particle types 3: without electron in coherent fit; when electron fraction > ~ 5e-2, like in pp7000jet, electrons can not be neglected
ntype=$(echo 4) ############################################### NO NEED TO CHANGE
# 3)

#corrections to signal mean
cors=$(echo SignalShift) ############################################### NO NEED TO CHANGE
#EnergyLossCorrection

########################################################################
#                          controls in MN2D
########################################################################

#resolution parametrization
sigma=$(echo 1000 3000 2000)

#regularization range 2=direct neighbour
#2 is the best
intp=$(echo 2 ) ############################################### NO NEED TO CHANGE

#tolerance
tols=$(echo 2.0 ) ############################################### NO NEED TO CHANGE
#0.5 0.1

#option, only 0 should be used
regopt=$(echo 0) ############################################### NO NEED TO CHANGE
#1 2 3 4

#FixMean
FVmean= ############################################### NO NEED TO CHANGE
#FixMean

#at very high momentum (>20GeV/c), fix the electron fraction to 1e-6; only effective when the statistics is high enough to go beyond 20 GeV/c
elec=$(echo  FixHighPElectronMode2)
#  FixHighPElectronMode1   FixHighPElectronMode0 ) 

#regws=$(echo default 2E3 1E4)

########################################################################
#
########################################################################

for ii in $dsets; do

for nrx in $(echo $xbs); do
    for nry in $(echo $ybs); do
        for x0 in $(echo $x0s); do
            for x1 in $(echo $x1s); do
            for method in $(echo $mm); do 
                for anchor in $(echo $anchorNs); do
                    for ancopt in $(echo $ancopts); do
                        for nt in $(echo $ntype); do
                            for corr in $(echo $cors); do
for res in $(echo $sigma); do 
    for polint in $(echo $intp); do 
        for tol in $(echo $tols); do
            for reg in $(echo $regopt); do 
                for el in $(echo $elec); do
                    #for regw in $(echo $regws); do

                        counter=$( expr $counter + 1 )

#enable to check number of jobs
#continue
                        
                        dir=$ii/coherent$jobid/XB$nrx\YB$nry\_Xmin$x0\_Xmax$x1\_$method\_anchor$anchor\_ancopt$ancopt\_NTYPE$nt\_$corr\_RES$res\_POLINT$polint\_Tol$tol\_RegOpt$reg\_$FVmean\_$el
#\_LOWPMAX$lpm
#\_RegWeight$regw
                        
                        echo $dir; 

                        mkdir -p $jobid\logs
                        cd $jobid\logs                        

                        jobfile=$jobid\id$counter\.sh

                        cat > $jobfile <<EOF
#!/bin/bash

#the above line should be the first line of the .sh file, important for condor!!

mkdir -p $dir; 
cd $dir    
cp $dd0/{fith,mn2d,dofith.sh,domn2d.sh} .

#####

echo
echo in jobfile:
echo
uname -a
echo

source $dd0/rootsys.sh

cd $TCF_PATH
echo pwd TCF_PATH:"\$(pwd)"

source source.sh

cd $dir
echo pwd dir:"$(pwd)"

export PATH=$(pwd)/:$PATH

echo ls
ls
echo

echo go

./dofith.sh ../../hist*.root
                
echo hi
date
./domn2d.sh

EOF

                        chmod +x $jobfile
                        
                        qsub -P alice -cwd -l h_rt=8:0:0,h_rss=2G  ./$jobfile 
                        #./$jobfile 
                        #exit;
                        #subcondor.sh $jobfile 

                        cd $dd0

                    done; done; done; done; done;done; done;
                    done; done; done; done; done;done; done;
done

done

echo
echo counter $counter
