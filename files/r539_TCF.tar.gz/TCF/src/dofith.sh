hist=$1

echo hist: $hist
echo

#ln -s $hist hist.root
cp $hist hist.root

echo fitting Rev0 ...
./fith $hist > see0.log

endn=5;

mkdir -p savepre

for now in $(seq 1 $endn);
do
    pre=$(expr $now - 1 )
    echo 
    echo now $now, pre $pre; 

    outpre=outfith_*Rev$pre.root

    echo fitting Rev$now from $outpre ...
    ls --color=tty -lhtB

    ./fith $outpre > see$now.log

    ls --color=tty -lhtB

    mv $outpre see$pre.log savepre/

   ls --color=tty -lhtB
   echo
   echo
   echo
done

ls --color=tty -lhtB

tail savepre/see*.log see*.log
