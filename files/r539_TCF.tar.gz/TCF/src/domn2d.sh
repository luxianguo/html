d0=$(pwd)

dir=$d0/coherentFit

mkdir $dir
cd $dir

cp ../outfith*.root .
ln -s outfith*.root hist.root

$(pwd)/../mn2d hist.root  > see.log 

ls

cd $d0







