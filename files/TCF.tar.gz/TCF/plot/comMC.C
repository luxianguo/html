//#include "headers.hh"

#define sty 0
#if sty
#include "../style2.h"
#endif


void comMC(const TString fgen, const TString fana, const Int_t ntype=4)
{

#if sty
  SetGlobalStyle(0);
#endif

  TCanvas *cc=new TCanvas;

#if sty
  PadSetup(cc);
#endif

  cc->SetRightMargin(0.01);
  cc->SetTopMargin(0.08);
  
  gStyle->SetOptTitle(1);

  //gPad->SetGrid(1,1);
  
  TString ngen[]={"fractionproton", "fractionpion", "fractionkaon", "fractionelectron"};
  const TString nana[]={"ProtonFraction", "PionFraction", "KaonFraction", "ElectronFraction"};

  const Int_t col[]={kBlue, kRed, kGreen+3, kMagenta};
  const Int_t anamsty[]={20, 21, 22, 23};

  TH1D * hgen[]={0x0,0x0,0x0,0x0};
  TGraphAsymmErrors * hana[]={0x0,0x0,0x0,0x0};

  Int_t counter = 0;

  const Double_t xmin = 0.5;
  Double_t xmax = -999;

  const TString pars[]={"p","#pi", "K", "e#times10"};

  TString tag=fana(0,fana.First('m'));
  tag=tag(tag.First('_')+1, tag.Length());
  printf("tag %s\n",tag.Data());

  TString tit;
  if(tag.Contains("MCpp2760")){
    tit="MC pp #sqrt{s}=2.76 TeV";
  }
  else if(tag.Contains("MCpp7000")){
    tit="MC pp #sqrt{s}=7 TeV";
  }
  else if(tag.Contains("MCPbPb0005")){
    tit="MC PbPb #sqrt{s_{NN}}=2.76 TeV 0-5%";
  }
  else if(tag.Contains("MCPbPb0510")){
    tit="MC PbPb #sqrt{s_{NN}}=2.76 TeV 5-10%";
  }
  else if(tag.Contains("MCPbPb1020")){
    tit="MC PbPb #sqrt{s_{NN}}=2.76 TeV 10-20%";
  }
  else if(tag.Contains("MCPbPb2040")){
    tit="MC PbPb #sqrt{s_{NN}}=2.76 TeV 20-40%";
  }
  else if(tag.Contains("MCPbPb4060")){
    tit="MC PbPb #sqrt{s_{NN}}=2.76 TeV 40-60%";
  }
  else if(tag.Contains("MCPbPb6080")){
    tit="MC PbPb #sqrt{s_{NN}}=2.76 TeV 60-80%";
  }
  else if(tag.Contains("pp2760") && !tag.Contains("MC")){
    tit="Data pp #sqrt{s}=2.76 TeV";
  }
  else if(tag.Contains("pp7000jet")){
    tit="Data pp #sqrt{s}=7 TeV in jets";
  }

  tit += " ALICE@LHC";

  if(tag.Contains("MC")){
    gPad->SetLogx();
    gPad->SetLogy();
  }
  else{
    gPad->SetLogx(0);
    gPad->SetLogy(0);
  }

  const Double_t hmin = gPad->GetLogy()?1.8e-2:0;
  const Double_t hmax = gPad->GetLogy()?1.5:1.02;

  TLegend *lg = 0x0;
  const Double_t xshift = gPad->GetLogx()?0:0.7;
  const Double_t yshift = gPad->GetLogy()?0.05:0.15;
  lg = new TLegend(xshift+0.13, yshift+0.54 ,xshift+0.53, yshift+0.74);

#if sty
  ResetStyle(lg, 0.10);
#endif

  lg->SetFillStyle(0);
  lg->SetBorderSize(-1);
  lg->SetHeader("TCF");

  //=======================================================================================

  TFile *fin1 = new TFile(fana);
  if(!fin1->IsOpen()){
    printf("no fana %s\n", fana.Data()); exit(1);
  }

  for(Int_t ii=0; ii<ntype; ii++){
    hana[ii]=(TGraphAsymmErrors*)gDirectory->Get(nana[ii]);
    if(!hana[ii]){
      printf("no hana %d\n", ii); gDirectory->ls(); exit(1);
    }

#if sty
    ResetStyle(hana[ii]);
#endif

    if(ii==3){
      for(Int_t ip=0; ip<hana[ii]->GetN(); ip++){
        hana[ii]->GetY()[ip]*=10;
        hana[ii]->GetEYlow()[ip]*=10;
        hana[ii]->GetEYhigh()[ip]*=10;
      }
    }

    if(xmax<0){
      xmax = 2 * hana[ii]->GetX()[hana[ii]->GetN()-1] - hana[ii]->GetX()[hana[ii]->GetN()-2] ;
    }

    hana[ii]->SetTitle(tit);        
    hana[ii]->SetMarkerStyle(anamsty[ii]);
    hana[ii]->SetMarkerColor(col[ii]);
    hana[ii]->SetLineColor(col[ii]);
    hana[ii]->SetMinimum(hmin);
    hana[ii]->SetMaximum(hmax);
    hana[ii]->GetXaxis()->SetTitle("p (GeV/c)");
    hana[ii]->GetYaxis()->SetTitle("fraction");
    hana[ii]->GetXaxis()->SetLimits(xmin, xmax);
    hana[ii]->Draw(counter?"p":"ap");
    lg->AddEntry(hana[ii], pars[ii]+ "", "p");
    counter++;
  }

  //=======================================================================================
  if(fgen.Length()){
    TFile *fin2=new TFile(fgen);
    if(!fin2->IsOpen()){
      printf("no fgen %s\n", fgen.Data()); exit(1);
    }

    for(Int_t ii=0; ii<ntype; ii++){
      hgen[ii]=(TH1D*)gDirectory->Get(ngen[ii]);
      if(!hgen[ii])
        break;

      if(ii==3){
        hgen[ii]->Scale(10);
      }

#if sty
      ResetStyle(hgen[ii]);
#endif

      hgen[ii]->SetLineColor(col[ii]);
      hgen[ii]->Draw("hist same"); 
      //lg->AddEntry(hgen[ii], pars[ii]+ " truth", "l");
      counter++;
    }

    const Double_t xban = xmin;
    const Double_t xeban = 0.05;
    Double_t bs[]={1, 1e-1, 1e-2, 1e-3};
    const Int_t nb = sizeof(bs)/sizeof(Double_t);
    for(Int_t ib=0; ib<nb; ib++){
      TGraphErrors * hban= new TGraphErrors(1);
      bs[ib]*=1.2;
      const Double_t yy = bs[ib]*1.05;
      const Double_t ey = 0.05*bs[ib];
      hban->SetPoint(0, xban, yy);
      hban->SetPointError(0, xeban, ey);
      hban->Draw("2");
    }
  }

  lg->Draw();

  cc->Print(tag+"_comMC.eps");
  cc->Print(tag+"_comMC.png");
}

int main()
{return 0;}
