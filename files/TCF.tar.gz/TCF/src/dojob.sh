## run this script like
## nohup ./dojob.sh &

########################################################################
#                NO NEED TO CHANGE
########################################################################

if [ $TCF_PATH\kk == kk ]
then
    echo TCF_PATH not set!! source.sh not sourced!
    exit
fi

#test
#nmod=$(svn st ../ | grep -v "?" |wc| awk '{print $1}')
nmod=0
if [ $nmod != 0 ]
then
    echo please commit all changes first
    svn st $TCF_PATH
    exit
fi

cat > rootsys.sh<<EOF
export ROOTSYS=$ROOTSYS
EOF

dd0=$(pwd)

########################################################################
#              define data sets and jobid
########################################################################

kmc=0
#dsets="$(find $(pwd)/DATA/*MC$kmc* -type l | grep 12GeV | grep IDFF )"
#dsets="$(find $(pwd)/DATA/*MC$kmc* -type l | grep 20GeV | grep Incl  | grep A3)"
dsets="$(find $(pwd)/DATA/*MC$kmc* -type d)"
#dsets="$(find $(pwd)/JET_pPb_DATA/*MC$kmc* -type d | grep c000 | grep ETA2)"
#dsets="$(find $(pwd)/JET_PP_DATA/*MC$kmc* -type d | grep JPT10-15 | grep ETA2)"

#can not use Q, R because they are status of the job in qstat
jobid=b2

#

echo
echo $dsets | tr -s ' ' '\n' 
echo $dsets | tr -s ' ' '\n' |wc
echo

#exit

########################################################################
#                       controls in dEdxGausN
########################################################################

#control of log10p rebin
xbs=$(echo 7 5)

#control of TPC signal rebin
ybs=$(echo  2)
# 3)
#

x0s=$(echo -9 )
#-9 ) ###################################### NO NEED TO CHANGE

x1s=$(echo 40 )

#BetheBloch parametrization
#lund, aleph and mBB is equivalent; mBB is faster and is the only one possible to work with ntype = 3 (without electron)
mm=$(echo mBB lund aleph) 
#BBXing)

#weight
anchorNs=$(echo  3 2 ) ############################################### NO NEED TO CHANGE 
#4 3 ) ############################################### NO NEED TO CHANGE 
#
ancopts=$(echo 0 1)  ############################################### NO NEED TO CHANGE   

#number of particle types 3: without electron in coherent fit; when electron fraction > ~ 5e-2, like in pp7000jet, electrons can not be neglected
ntype=$(echo 4) ############################################### NO NEED TO CHANGE
# 3)

#corrections to signal mean
cors=$(echo SignalShift) ############################################### NO NEED TO CHANGE
#EnergyLossCorrection

########################################################################
#                          controls in MN2D
########################################################################

#resolution parametrization
sigma=$(echo 1000 3000 2000)

#tolerance
tols=$(echo 2.0 ) ############################################### NO NEED TO CHANGE
#0.5 0.1

#option, only 0 should be used
#regopt=$(echo 0) ############################################### NO NEED TO CHANGE (only used for npol=2 which is too soft)
#good 
regopt=$(echo 1) ############################################### regopt 1 (linear fit x^1) best
#1 2 3 4

#regularization range 2=direct neighbour, n=+/-n/2, -999: maximal n
intp=$(echo 6 10 ) ############################################### regopt=0 intp=2 should be the same as regopt=1, intp=2 (confirmed); should average over regopt1, intp= 6,10


#FixMean
FVmean= ############################################### NO NEED TO CHANGE
#FixMean

#at very high momentum (>20GeV/c), fix the electron fraction to 1e-6; only effective when the statistics is high enough to go beyond 20 GeV/c
elec=$(echo  FixHighPElectronMode2)
#  FixHighPElectronMode1   FixHighPElectronMode0 ) 

#regws=$(echo default 2E3 1E4)

#for pPb to avoid overlapping with physics value
cpini=$(echo N5)
#for pp Cp~0, can't go N5 that far
#cpini=$(echo N2)
#0 N1)

########################################################################
#                           START LOOP HERE
########################################################################

nfile=0

logdir=$jobid\logs
mkdir -p $logdir
cd $logdir                        

filetag=$jobid
#\A$nfile

#global counter #refresh counter
counter=0

for ii in $dsets; do

    nfile=$( expr $nfile + 1 )

echo nfile $nfile
#enable to check number of files
#continue

for icp in $(echo $cpini); do
for nrx in $(echo $xbs); do
    for nry in $(echo $ybs); do
        for x0 in $(echo $x0s); do
            for x1 in $(echo $x1s); do
for method in $(echo $mm); do 
    for anchor in $(echo $anchorNs); do
        for ancopt in $(echo $ancopts); do
            for nt in $(echo $ntype); do
for corr in $(echo $cors); do
    for res in $(echo $sigma); do 
        for reg in $(echo $regopt); do 
            for polint in $(echo $intp); do
                                                
        #if [ $reg == 0 ] 
        #then
        #    polint=2
        #else
        #    polint=6
        #fi

for tol in $(echo $tols); do
    for el in $(echo $elec); do
                    #for regw in $(echo $regws); do
        
        counter=$( expr $counter + 1 )
        
        
#enable to check number of jobs
#continue
        
        dir=$ii/coherent$jobid/XB$nrx\YB$nry\_Xmin$x0\_Xmax$x1\_$method\_anchor$anchor\_ancopt$ancopt\_NTYPE$nt\_$corr\_RES$res\_POLINT$polint\_Tol$tol\_RegOpt$reg\_$FVmean\_$el\_CpIni$icp
#\_LOWPMAX$lpm
#\_RegWeight$regw
        
                        #echo $dir; 
        
                        #svn info $TCF_PATH > seesvn.log
        
        jobfile=$filetag\C$counter\.sh
        
        cat > $jobfile <<EOF
#!/bin/bash

#the above line should be the first line of the .sh file, important for condor!!

mkdir -p $dir; 
cd $dir    
cp $dd0/{fith,mn2d,dofith.sh,domn2d.sh} .

#####

echo
echo in jobfile:
echo
uname -a
echo

source $dd0/rootsys.sh

cd $TCF_PATH
echo pwd TCF_PATH:"\$(pwd)"

source source.sh

cd $dir
echo pwd dir:"$(pwd)"

export PATH=$(pwd)/:$PATH

echo ls
ls
echo

echo go

./dofith.sh ../../hist*.root
                
echo hi
date

#use timeout here
timeout 6h ./domn2d.sh

date

EOF

        chmod +x $jobfile
                        
                        #qsub -P alice -cwd -l h_rt=8:0:0,h_rss=2G  ./$jobfile 

                        #OX: normal 168h,  short 12h, veryshort 2h
                        #https://www2.physics.ox.ac.uk/it-services/ppunix/particle-physics-linux-batch-farm
                        #walltime is time on the wall                        
        qsub -l cput=06:00:00 -N $jobfile  ./$jobfile 

        nq=$(qstat | grep $(whoami) | grep Q |wc | awk '{print $1}' )
        while [ $nq -gt 10 ]
        do
            sleep 10
            nq=$(qstat | grep $(whoami) | grep Q |wc | awk '{print $1}' )
        done

#test
        #./$jobfile 
        #exit;
                        #subcondor.sh $jobfile 

    done; done; done; done;
    done; done; done; done; 
    done; done; done; done;
    done; done; done;

done

exit

#only submit once

cat > $filetag\.sh <<EOF
#!/bin/bash

cd $dd0/$logdir

./${filetag}C\${PBS_ARRAYID}.sh

#test
#ls ./${filetag}C\${PBS_ARRAYID}.sh; sleep 120;

exit 0;

EOF


echo
echo nfile $nfile
echo counter $counter
echo

pwd
readlink -f ${filetag}.sh

#OX maximum slot in an array 350 (350 OK, 351 fail), single job slot limit > 800
dn=288
#350
n0=1
n1=$dn

narr=1

while [ $n1 -le $counter -a $n0 -lt $n1 ]
do
#route to normal queue; short queue at OX is not stable
    que="-l cput=18:00:00"

    #if [ $narr -gt 1 ]
    #then
    #    que="$que -W depend=afteranyarray:${lastjob}[]"
    #fi

    aa="qsub $que -N ${filetag}A$narr -t ${n0}-${n1} ${filetag}.sh"

    echo    
    echo $aa

#submit    re-submit

#test
#set as 0 to enter submitting
    jok=0
    while [ $jok -eq 0 ]
    do
        lastjob=$(eval $aa | awk -F\[ '{print $1}')
        echo lastjob $lastjob
        sleep 3;
        jok=$(qstat | grep $lastjob | wc | awk '{print $1}')
        echo jok $jok
    done
    
    n0=$( expr $n0 + $dn )
    n1=$( expr $n1 + $dn )
    if [ $n0 -lt $counter -a  $n1 -gt $counter ]
    then
        n1=$counter
    fi

    narr=$( expr $narr + 1 )

done




