
if [ $TCF_PATH\kk == kk ]
then
    echo "TCF_PATH not set! do"
    echo "source source.sh"
    exit
fi



#################################################################
#getGrSys on drawpar output
#used also for TOF cases

dd0=$(pwd)

absd=$TCF_PATH/SysUtils
predo="export ROOTSYS=$ROOTSYS; cd $TCF_PATH; source ./source.sh; cd -;"

#exec=execlocal
exec=execqsub

#################################################################

#no fit, beta11
#test
#kCheckCp=0
#real fit, beta22
kCheckCp=1

###############################################################

#normal
for ii in $(echo DAT*)
  do



###############################################################      

#check!!
#should include also bad* which are to be rejected by setbadid in getGrSys        

#full, cmpTPC

#for Cp~0
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep kHESSE1_fkErr0_iBeta2  | grep _rb1 | grep khm0 | grep CpIniN2"

#beta3 for pPb because Cp != 0
files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep kHESSE1_fkErr0_iBeta3  | grep _rb1 | grep khm0 | grep CpIniN5"

#test
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep kHESSE1_fkErr0_iBeta3  | grep _rb1 | grep khm0 | grep  CpIniN4  "

#beta11
#test
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep Beta11  | grep _rb1 | grep khm0 |  grep CpIniN5"

#cmpXmin
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep Beta11  | grep _rb1 | grep khm0 | grep ancopt1 "
#files="find \$(pwd)/../XB*/co*/$exec/*parm*Beta*.root | grep Beta22  | grep _rb1 | grep khm0 "

###########################################################

#if there is Sys01 and 02 then should not use qusb, Sys10 may not yet produced

#all IDs
#for grid in $(echo {1,6,2,3,7,8}{0,3} 0{1,2}  )
#discard xi
#for grid in $(echo {1,6,2,7}{0,3} 0{1,2}  )
#for pPb only pt
#for grid in $(echo 1{0,3}  0{1,2} )
#only physics
for grid in $(echo 1{0,3}  )

#with MC
#for grid in $(echo {1,6}{0,3} )

#cmpXmin,cmpBeta11
#for grid in $(echo 10 )

#cmpTPC
#for grid in $(echo {1,6}0 0{1,2} )

#fast ID 
#for grid in $(echo {1,6,2,7}0 )
#for grid in $(echo 10 )
#for grid in $(echo {1,6,2,7}{0,3} )
#pure MC
#for grid in $(echo {6,7}{0,3} )


####

#test MC, with TOF
#for grid in $(echo {1,6,2,3,7,8,9}{0,3} {0,5}8  )

#test mean
#for grid in $(echo 10 {0,5}{1,2} )

#################################################################

    do 
        dir=$dd0/$ii/Sys$grid
        echo $dir
        mkdir -p $dir
        cd $dir

        cat > subgetgr.sh <<EOF
#!/bin/sh

uname -a

$predo

cd $dir

echo ls
ls
echo

echo pwd
pwd
echo

                                                                                                                                                         
export PATH=$(pwd)/:$PATH
                         
echo go

rm -f in.log

ksetbad=1

if [ ${grid:0:1} == 0 -o ${grid:0:1} == 5  ]
then

grep accept ../Sys10/see10.log | awk '{print \$7}' | grep XB5   > in.log 
ksetbad=0

#$files | grep XB5 > in.log      

else

$files > in.log

fi
            
wc in.log
            
$absd/getGrSys in.log $grid \$ksetbad $kCheckCp > see$grid.log

EOF

        chmod +x ./subgetgr.sh;    
        #qsub -P alice -cwd -l h_rt=1:0:0,h_rss=1G  ./subgetgr.sh
        #qsub  ./subgetgr.sh
        #if there is Sys01 and 02 then should not use qusb, Sys10 may not yet produced
        ./subgetgr.sh
        cd -


    done

done


