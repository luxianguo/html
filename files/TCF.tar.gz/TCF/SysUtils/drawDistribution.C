void drawDistribution(const TString fin, const TString tag)
{
  TFile::Open(fin);

  gStyle->SetOptStat("ou");

  TCanvas *c1=new TCanvas;
  gPad->SetLogx(1);

  Char_t * nn[]={"proton","pion","kaon","electron"};
  for(Int_t ii=0; ii<4; ii++){
    TGraphAsymmErrors * gr = (TGraphAsymmErrors*) gDirectory->Get(Form("grsys%d", ii));
    gr->SetFillStyle(0);

    //both are id10, not directly the one used for setbadid
    hbefore = (TH2D*)gDirectory->Get(Form("%sbefore%dhh", tag.Data(), ii));
    hbefore->SetTitle(Form("before cut;%s (GeV/c);%s fraction", tag.Contains("pt")?"p_{T}":"p", nn[ii]));
    hbefore->GetXaxis()->SetRangeUser(0.1,40);
    if(tag.Contains("pt")){
      if(ii==1){
        hbefore->GetYaxis()->SetRangeUser(0.5,1);
      }
      else{
        hbefore->GetYaxis()->SetRangeUser(0,0.5);
      }
    }
    else{
      hbefore->GetYaxis()->SetRangeUser(0,1);
    }
    hbefore->Draw("colz");
    gr->Draw("2");

    c1->Print(Form("%s%da.eps",tag.Data(), ii));

    //both are id10, not directly the one used for setbadid
    hafter = (TH2D*)gDirectory->Get(Form("%safter%dhh",tag.Data(), ii));
    hafter->SetTitle(Form("after cut;%s (GeV/c);%s fraction", tag.Contains("pt")?"p_{T}":"p", nn[ii]));
    hafter->GetXaxis()->SetRangeUser(0.1,40);
    if(tag.Contains("pt")){
      if(ii==1){
        hafter->GetYaxis()->SetRangeUser(0.5,1);
      }
      else{
        hafter->GetYaxis()->SetRangeUser(0,0.5);
      }
    }
    else{
      hafter->GetYaxis()->SetRangeUser(0,1);
    }

    hafter->Draw("colz");
    gr->Draw("2");
    c1->Print(Form("%s%db.eps",tag.Data(), ii));
  }

}
