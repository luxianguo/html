#!/bin/sh

#only do beta100
for ii in $(find ../outmn2d_post_kHESSE1_fkErr0*Beta*.root ) 
do
    echo $ii
    tt=$(echo $ii | tr -s './' ' ' | awk '{print $1}' | tr -d '_' )
    echo $tt

    dd=$(echo 1)

    #kxmin=$(pwd | grep Xmin-9 | wc | awk '{print $1}')
    #ktpc1tof9=$(pwd | grep TPC1TOF9 | wc | awk '{print $1}')

    #if [ kk$kxmin == kk1 -a kk$ktpc1tof9 == kk1 ]
    #then
    #    dd=$(echo 1 3 5 7)
    #fi

    for rb in $dd
    do
        for khm in $(echo 0)
        do
            ./drawpar  $ii $rb $khm > seedrawpar_$tt\_rb$rb\_khm$khm\.log
        done
    echo 
    done
    echo
done

#./drawpar hist.root  > seedrawpar_fith.log


