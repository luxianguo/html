#include "headers.hh"
#include "style.h"

const Int_t fColBl = kBlack;//7; //
const Int_t col[]={fColBl, kRed, kGreen+3, kMagenta, fColBl, kRed, kGreen+3, kMagenta};
const Int_t msty[]={23,26,32,22, 27,24,30,20};
const TString stype[]={" p", " #pi", " K", " e"};

void ScaleErrY(TGraphAsymmErrors * gr, const Double_t fac)
{
  for(Int_t ii=0; ii<gr->GetN(); ii++){
    gr->GetEYlow()[ii]*=fac;
    gr->GetEYhigh()[ii]*=fac;
  }
}

void drawGr(const Bool_t kref, const Int_t itype, const Int_t nfile, TGraphAsymmErrors * tmpstat[], TGraphAsymmErrors * tmpsys[], const TString title, const TString header, const Double_t yerrfac, const TString tag, const TString toks[])
{
    TLegend *lg = new TLegend(0.86, 0.5, 0.99, 0.99);
    style::ResetStyle(lg);

    lg->SetHeader(Form("#splitline{%s}{#sigma_{y stat}#times%.0f}",(header+stype[itype]).Data(), yerrfac));

    Double_t xmin = 1e5;
    Double_t xmax = -1e5;
    Double_t ymin = 1e5;
    Double_t ymax = -1e5;

    for(Int_t ifile=0; ifile<nfile; ifile++){
      TGraphAsymmErrors * gstat=tmpstat[ifile];
      TGraphAsymmErrors * gsys=tmpsys[ifile];

      style::ResetStyle(gstat);
      style::ResetStyle(gsys);

      gstat->SetTitle(Form(";%s",title.Data()));

      gstat->SetMarkerStyle(msty[ifile]);
      gstat->SetMarkerColor(col[ifile]);
      gstat->SetLineColor(col[ifile]);

      gsys->SetMarkerStyle(msty[ifile]);
      gsys->SetMarkerColor(col[ifile]);
      gsys->SetLineColor(col[ifile]);

      style::GraphMinMaxXY(gsys, xmin, xmax,  ymin, ymax);

      gsys->SetFillStyle(ifile==0?3001:0);

      lg->AddEntry(gstat,toks[ifile], "lp");
    }

    if(tag.Contains("ID01")){
      ymax = 85;

      ymin = 40;
      if(itype==3){
        ymin = 70;
      }

      xmin = 0.1;
      xmax = 20;
    }

    if(kref){
      /*
      const Double_t thres = 4;
      if(ymax > thres){
        ymax = thres;
      }
      */

      ymax = 1.5;
      ymin = 0.5;
    }

    printf("fastComp ymin %e ymax %e\n", ymin, ymax);

    for(Int_t ifile=0; ifile<nfile; ifile++){
      TGraphAsymmErrors * gstat=tmpstat[ifile];
      TGraphAsymmErrors * gsys=tmpsys[ifile];

      gstat->SetMinimum(ymin<EPSILON? EPSILON : ymin);
      gstat->SetMaximum(ymax);
      gstat->GetXaxis()->SetLimits(xmin, xmax);

      gstat->GetYaxis()->SetMoreLogLabels();

      if(kref){
        gstat->GetYaxis()->SetTitle("scaled to first set");
      }

      gstat->Draw(ifile==0?"alp":"lp");
      gsys->Draw("2");
    }

    lg->Draw();
}


void fastComp(const Int_t nfile, const TString files[], const TString tag, const Double_t yerrfac)
{
  
  TGraphAsymmErrors * grstat[nfile][4];
  TGraphAsymmErrors * grsys[nfile][4];

  for(Int_t ifile = 0; ifile < nfile; ifile++){
    TFile *fin = new TFile(files[ifile]);
    for(Int_t itype=0; itype<4; itype++){
      grstat[ifile][itype]=(TGraphAsymmErrors*) fin->Get(Form("grstat%d",itype));
      if(!grstat[ifile][itype]){
        printf("no grstat ifile %d itype %d\n", ifile, itype);
        fin->ls();
        exit(1);
      }
   
      ScaleErrY(grstat[ifile][itype], yerrfac);
 
      grsys[ifile][itype]=(TGraphAsymmErrors*) fin->Get(Form("grsys%d",itype));
      if(!grsys[ifile][itype]){
        printf("no grsys ifile %d itype %d\n", ifile, itype);
        fin->ls();
        exit(1);
      }

    }
  }

  //===================
  TGraphAsymmErrors * refstat[nfile][4];
  TGraphAsymmErrors * refsys[nfile][4];

  for(Int_t ifile=0; ifile<nfile; ifile++){
    for(Int_t itype=0;itype<4; itype++){
      refstat[ifile][itype] = style::ScaleGraph(grstat[ifile][itype], grstat[0][itype]);
      refsys[ifile][itype]  = style::ScaleGraph(grsys[ifile][itype],  grsys[0][itype]);
    }
  }
  //===================

  style::SetGlobalStyle();

  TCanvas *cc=new TCanvas("cc","",1800,600);
  cc->Divide(2);
  style::fgkYTitleOffset = 1.5;

  style::PadSetup(cc);

  for(Int_t ii=1; ii<=2; ii++){
    cc->cd(ii);
    gPad->SetRightMargin(0.15);
    gPad->SetLeftMargin(0.15);
    gPad->SetTopMargin(0.05);
    gPad->SetBottomMargin(0.15);
  }

  TString toks[100];
  toks[99]=tag;
  toks[99].ReplaceAll("__","_");
  Int_t ntok=0;

  const TString title = toks[99](0,toks[99].First("_"));
  toks[99]=toks[99](toks[99].First("_")+1,toks[99].Length());

  const TString header = toks[99](0,toks[99].First("_"));
  toks[99]=toks[99](toks[99].First("_")+1,toks[99].Length());

  printf("title %s header %s\n", title.Data(), header.Data());

  while(toks[99].Contains("_")){
    toks[ntok]=toks[99](0,toks[99].First("_"));
    toks[99]=toks[99](toks[99].First("_")+1,toks[99].Length());
    ntok++;
  }
  for(Int_t ii=0; ii<ntok; ii++){
    printf("tok %d %s\n", ii, toks[ii].Data());
  }

  for(Int_t  itype=0; itype<4; itype++){
    if(tag.Contains("-13-") && itype==1)
      continue;

    TGraphAsymmErrors *tmpstat[nfile];
    TGraphAsymmErrors *tmpsys[nfile];

    //------->
    cc->cd(1);
    for(Int_t ifile=0; ifile<nfile; ifile++){
      tmpstat[ifile] = grstat[ifile][itype];
    }
    for(Int_t ifile=0; ifile<nfile; ifile++){
      tmpsys[ifile] = grsys[ifile][itype];
    }
    drawGr(0, itype, nfile, tmpstat, tmpsys, title, header, yerrfac, tag, toks);

    cc->cd(2);
    gPad->SetGrid();
    for(Int_t ifile=0; ifile<nfile; ifile++){
      tmpstat[ifile] = refstat[ifile][itype];
    }
    for(Int_t ifile=0; ifile<nfile; ifile++){
      tmpsys[ifile] = refsys[ifile][itype];
    }
    drawGr(1, itype, nfile, tmpstat, tmpsys, title, header, yerrfac, tag, toks);

    for(Int_t ii=0; ii<2; ii++){
      for(Int_t jj=0; jj<2; jj++){
        cc->cd(1);
        gPad->SetLogx(ii);
        gPad->SetLogy(jj);

        cc->cd(2);
        gPad->SetLogx(ii);
        gPad->SetLogy(jj);
        TString outtmp(tag);
        outtmp.ReplaceAll(";","");
        outtmp.ReplaceAll(" ","");
        outtmp.ReplaceAll("(GeV/c)","");
        outtmp.ReplaceAll("(","");
        outtmp.ReplaceAll(")","");
        outtmp.ReplaceAll("/","");

        cc->Print(Form("outfast_itype%d_%s_logx%d_logy%d.png", itype, outtmp.Data(), ii, jj));
      }
    }
  }
}

int main(int argc, char * argv[])
{
  for(Int_t ii=0; ii<argc; ii++){
    printf("%d: %s\n", ii, argv[ii]);
  }

  TString files[10];
  Int_t nfile = 0;
  for(Int_t ii=1; ii<argc-2; ii++){
    files[nfile]=argv[ii];
    nfile++;
  }

  printf("nfile: %d\n", nfile);

  fastComp(nfile, files, argv[nfile+1], atoi(argv[nfile+2]));

  return 0;
}
