##########################################
0. 

test/DATA/link.sh
edit test/dojob.sh
jobmonitor.sh
run test/dojob.sh

##########################################
1.1 check executed jobs (at test/)

#to modify according to jobid in dojob.sh
ver=U1

for pp in $(find DATA*/*THnI*/co*$ver/X*/hist.root ); do ii=$(dirname $pp);  jj=$(grep "1: hist.root" $ii/coh*/see.log |wc| awk '{print $1}'); echo $ii $jj ;done > seehead.log

date; tt=0; ss=0; for ii in $(seq 0 1); do jj=$(cat seehead.log | awk '{if($2=='$ii')print}' |wc | awk '{print $1}'); tt=$( expr $tt + $jj); ss=$(echo $ii $jj $ss | awk '{print $1*$2+$3}'); echo $ii $jj $tt $ss; done > seehead01.log

#output: first line number of failed jobs, second line number of executed jobs
cat seehead01.log

##########################################
1.2 move fit output

gg=$ver\finish

mkdir $gg/TPC1TOF9

for mm in $(echo $gg/TPC*); do aa=$(basename $mm); for kk in $(echo DATA/*THnI*$aa\*/coh*$ver | tr -s ' ' '\n'); do pp=$(echo $kk | tr -s '/' '_');  dir=$gg/$aa/$pp; mv $kk $dir; done; done

cd $gg

for pp in $(find TPC*/*THnI*co*/X*/hist.root ); do ii=$(dirname $pp);  jj=$(grep "mn2d done" $ii/coh*/see.log |wc| awk '{print $1}'); echo $ii $jj ;done > seemn2ddone.log

date; tt=0; ss=0; for ii in $(seq 0 1); do jj=$(cat seemn2ddone.log | awk '{if($2=='$ii')print}' |wc | awk '{print $1}'); tt=$( expr $tt + $jj); ss=$(echo $ii $jj $ss | awk '{print $1*$2+$3}'); echo $ii $jj $tt $ss; done > seemn2ddone01.log

## to show which jobs failed
## only effective if there is 0 in seemn2ddone01.log ##-->
wc $(cat seemn2ddone.log | awk '{if($2==0) print $1"/co*/see.log"}') | sort -n > see0log.log
head see0log.log

for ii in  $(cat seemn2ddone.log | awk '{if($2==0) print $1"/co*/see.log"}'); do echo $ii; tail -n 2 $ii; echo; done > see0tail.log
cat see0tail.log
##<--

#display the success rate in each iteration
#the list is too excessive, so seeing "find: `TPC*/*coher*/X*/co*/outmn2d*kHESSE1_fkErr0*Beta225*': No such file or directory" is fine
bbs=$(echo 11{2,3,4,5,6,7,8} 22{1,2,3,4,5,6,7,8,9} 230 3{3,4})

for ii in $(echo $bbs); do echo $ii;  find TPC*/*coher*/X*/co*/outmn2d*kHESSE1_fkErr0*Beta$ii* > seeErr0Beta$ii\.log; find TPC*/*coher*/X*/co*/outmn2d*kHESSE1_fkErr4*Beta$ii* > seeErr4Beta$ii\.log; done

for ii in $(echo $bbs); do wc seeErr*Beta$ii*; echo;  done

wc seeErr*Beta1* | grep -v " 0 "

wc seeErr*Beta2* | grep -v " 0 "

wc seeErr*Beta3* | grep -v " 0 "

##########################################

1.3 convert results (no change of directory, but need to go to SysUtils/ and compile.sh first)

cat > tmpdo.sh <<EOF

if [ $TCF_PATH\kk == kk ]
then
    echo "TCF_PATH not set! do"
    echo "source source.sh"
    exit
fi

rm -f nohup.out
nohup $TCF_PATH/SysUtils/subdrawpar.sh &
EOF

chmod +x tmpdo.sh

for ii in $(echo TPC*); do echo $ii; cd $ii;   ../tmpdo.sh; cd -;done

#wait until it finshes, should not take long; once jobs finished, ctrl+C to end the loop
for ii in $(seq 0 10000); do echo $ii; qstat -u $(whoami); sleep 2; done

##########################################

1.4 check drawpar output

RB=1
KHM=

exec=execqsub
#exec=execlocal

#should be number of all submitted jobs
for ii in $(echo TPC*/*coher*/X*/co*/$exec/seedra*rb$RB*khm$KHM*.log); do jj=$(grep drawpardone $ii |wc| awk '{print $1}'); echo $ii $jj; done  > seealldrawpardone.log

grep -v "*" seealldrawpardone.log  |wc

#should show nothing, unless too sparse entries so that there is missing point in the graph and hence failing drarpar
cat seealldrawpardone.log | awk '{if($2==0) print }'

target=$(echo 1 2 3) # 11) #
bbs=$(echo $target)
for ii in $(echo $bbs); do  find TPC*/*coher*/X*/co*/$exec/*parmn2d*Beta$ii*rb$RB*khm$KHM*.root > seegoodBeta$ii\.log ; done

#Err0+Err4=mn2d01
#Beta101 > 201 > 202 > 301 > 302 = mn2d01
#good+bad12 = Err0 in case all drawpar done
for ii in $(echo $bbs); do wc see*Err*Beta$ii*;   wc see*good*Beta$ii* ; echo; done

#should = drawpar done
for ii in $(echo $bbs); do
echo $ii $(grep  -v "*"  seealldrawpardone.log | awk '{if($2!=0) print}' | grep Beta$ii |wc)
#due to HyperMatrix, the number of (good+bad) = 2 * Err0
wc seegoodBeta*$ii*
done

for bt in $(echo 2 3); do

wc seeErr0Beta${bt}*

wc seeErr*Beta${bt}*

done

cat seemn2ddone01.log

#if not zero, check and possibly need to resubmit
cat seealldrawpardone.log | awk '{if($2==0) print }' |wc


mkdir keeplog
mv see*.log keeplog

##########################################

1.5 produce systematic errors

rm -rf TPC*/*/*Sys*

cat > tmpdo.sh <<EOF

if [ $TCF_PATH\kk == kk ]
then
    echo "TCF_PATH not set! do"
    echo "source source.sh"
    exit
fi

rm -f nohup.out
nohup $TCF_PATH/SysUtils/jobgetGrSys.sh &
EOF
chmod +x tmpdo.sh

for ii in $(echo TPC*); do echo $ii; cd $ii;   ../tmpdo.sh; cd -;done


sleep 3

#ctrl+C to go out
tail -f TPC*/nohup*


##########################################

1.6 check output from 1.5

#pt, z
#ids=$(echo  {1,2}{0,3} )

#only pT
ids=$(echo  1{0,3} )
for id in $(echo $ids);do for ii in $(echo TPC*/*/Sys$id/see*.log); do jj=$(grep getGrSysdone $ii  |wc); echo $ii $jj ; done; done> seeGrSysdone.log
cat seeGrSysdone.log | awk '{if($2==0) print}' | grep Sys10

for id in $(echo $ids); do echo $id; grep acceptedfraction TPC*/*/Sys$id/see*.log; echo; done > seeGrSysFractions.log
cat seeGrSysFractions.log | grep Sys10 | awk '{if($4 <0.5 ) print}' | sort -n -k 4

for grid in $(echo $ids ); do  wc  TPC*/*/Sys$grid/in.log  | sort -n > seein$grid\.log; done

for grid in $(echo $ids ); do  jj=$( grep getGrSysdone TPC*/*/Sys$grid/see$grid\.log | wc); echo $jj $grid; done | sort -n > seeout.log;
cat seeout*

cat seein10.log

wc keeplog/see*Beta1*.log

wc keeplog/see*Beta2*.log

wc keeplog/see*Beta3*.log


##################################################

1.7 draw parameter distributions before and after outlier removal

dd=$TCF_PATH/SysUtils

for ii in $(echo TPC*/DATA*co*/Sys10*); do cd $ii; ln -s $dd/drawDistribution.C; ff=$(find out*.root); echo $ff;root -b -l -q 'drawDistribution.C("'$ff'","pt")'; cd -; done

rm -rf distri
mkdir distri
for ii in $(echo TPC*/DATA*co*/Sys10/*.eps); do jj=$(echo $ii| tr -s '/' '_'); cp $ii distri/$jj; done


##################################################

1.8 draw Cp distribution 


mkdir BiCorrection
cd BiCorrection

find ../TPC*/*/Sys10/see10.log |wc

#has to be adjusted according to whether Beta2 or Beta3 are used!!!
target=3


for ii in $(echo $(pwd)/../TPC*/*/Sys10/see10.log); do 
    for kk in $(grep "accepted file" $ii | awk '{print $7}'); do 
        zz=$(dirname $kk)/../outmn2d*kHESSE1_fkErr0_iBeta${target}*.root ; 
        find $zz; 
    done; 
done > allgood${target}.log

wc allgood${target}.log
chmod -w allg*.log

ln -s  $TCF_PATH/SysUtils/drawBiCorrection

./drawBiCorrection all $target


ts=$(echo  E{U,T}A{0,1,2,3} ancopt{0,1}  aleph lund mBB XB{5,7} YB{2,3} RES{1,2,3} Incl IDFF c000_010 c010_040 c040_100 JPT{5,10,15})

for tag in $ts; do echo $tag; mkdir $tag; cd $tag; grep $tag ../allgood$target\.log > allgood$target\.log;  wc all*.log;  ../drawBiCorrection $tag $target  ;    cd - ;  done

mkdir biplot
cp *.eps */*.eps biplot

cd ../


##################################################

1.9 draw fit on dEdx (must have Sys01,02 first, can skip on first try)

ln -s $TCF_PATH/SysUtils/doDrawMean.sh
ln -s $TCF_PATH/SysUtils/drawMeanGrSys01

rm -rf TPC*/DATA*/meanSummary

for ii in $(echo TPC*/DATA*/); do dd=$ii/meanSummary; mkdir $dd; cd $dd; pwd; ln -s ../../../drawMeanGrSys01; ln -s ../../../doDrawMean.sh do.sh; ./do.sh ; cd -;done

rm -rf drawMean
mkdir drawMean
for ii in $(echo TPC*/DATA*/meanSummary/*.eps); do jj=$(echo $ii | tr -s '/' '_'); cp $ii drawMean/$jj; done


##################################################
1.10 compare eta


tof=TPC1TOF9
#ids=$(echo 1{3,0} 0{1,2})
ids=$(echo 1{3,0})
dd0=$(pwd)


for grid in $(echo $ids)
do
#determine difference between dirs
    ndir=0
    tmp=cmpetatmp
    alld=$(echo $tof/DATA*  | sed s/ETA[0-9]/ETAX/g  | sed s/EUA[0-9]/ETAX/g | sed s/c000_010/c000/g | sed s/c010_040/c010/g | sed s/c040_100/c040/g | sed s/_0d/0d/g | tr -s ' ' '\n'|  sort -u)
    
    for pp in $alld
    do
        #echo $pp
        ndir=$( expr $ndir + 1 )
        echo $pp  | tr -s '/' '_' | tr -s  '_' '\n' | sort -u > ${tmp}$ndir
    done
    
    cat ${tmp}* | sort -u > ${tmp}all
    
    rm -f alltag
    for ii in $(seq 1 $ndir)
    do
        diff ${tmp}$ii ${tmp}all -y | grep ">" | tr -s '>' ' ' >> alltag
    done
    #cat alltag 
    rm -f cmpetatmp*
    
    datatype=$(cat alltag | sort -u | grep -v p0d | grep -v n0d| tr -s '\n' ' ')
    if [ $datatype\k == k ]
    then
        datatype=_
    fi
    
    for tag in  $datatype
    do
        #echo $tag
        
        #nd=$(echo $alld | tr -s ' ' '\n'| grep $tag |wc  | awk '{print $1}')
        #if [ $nd != 1 ]
        #then
        #    continue
        #fi
        
        
        dir=cmpEta_$tof\_GrID$grid/$tag
    #echo $dir
        
        mkdir -p $dir
        touch $(dirname $dir)
        
        cd $dir
        etatag=
        for jj in $(echo E{U,T}A{0,1,2,3})
        do
            #file=$(echo $(echo $dd0/$pp | sed s/ETAX/E${pn}A$jj/g)/Sys$grid/out*.root
            file=$(echo $dd0/$tof/DATA*${tag}*$jj*/Sys$grid/out*.root)
            if [ ! -e $file ]
            then
                file=$(echo $dd0/$tof/DATA*$jj*${tag}*/Sys$grid/out*.root)
                if [ ! -e $file ]
                then
                    continue;
                fi
            fi
            
            echo $file
            echo 
            ln -s $file ID$grid$jj.root
            etatag="${etatag} $jj"
        done
        
        etatag=$(echo $etatag | tr -s ' ' '\n' |sort | tr -s '\n' '_')
        echo test1
        echo $etatag
        echo test2

        ln -s $TCF_PATH/SysUtils/fastComp
        
        ./fastComp *.root "p (GeV/c);ID${grid}_${tag}a_${etatag}-${grid}-" 10 > see.log
        
        cd $dd0
    done
    rm -f alltag
done

mkdir plotCmpEta
cp cmpEta*/*/*.png plotCmpEta

##################################################

1.11 combine eta


ln -s $TCF_PATH/SysUtils/getCombFrac

tof=TPC1TOF9
ids=$(echo 1{3,0})
dd0=$(pwd)

for grid in $(echo $ids)
do
    for pp in $(echo $tof/DATA*  | sed s/ETA[0-9]/ETAX/g  | sed s/EUA[0-9]/ETAX/g | sed s/[a-z]0d[0-9]_0d[0-9]/""/g  |tr -s ' ' '\n'|  sort -u )
    do
#echo $pp
 
        tag=$(echo $pp  | tr -s '/' '_' )
  #echo $tag
        
        dir=recomEta_$tof\_GrID$grid/$tag
    #echo $dir
        
        mkdir -p $dir
        touch $(dirname $dir)
        
        cd $dir
        
        for jj in $(echo E{U,T}A{0,1,2,3})
        do
            file=$(echo $(echo $dd0/$pp | sed s/ETAX_/$jj\_*/g)/Sys${grid:0:1}0/out*.root)
            if [ ! -e $file ]
            then
                continue
            fi

        #echo $file
            ln -s $file frac$jj.root
            
            file=$(echo $(echo $dd0/$pp | sed s/ETAX_/$jj\_*/g)/Sys${grid:0:1}3/out*.root)
        #echo $file
            ln -s $file ratio$jj.root
            
            file=$(find $(dirname $file)/../*/hist.root | head -n 1)
        #echo $file
            ln -s $file raw$jj.root
        done
        
        ln -s ../../getCombFrac ; ./getCombFrac > see.log; echo "see done:"; grep donedone see.log |wc ; echo ; 
        
        cd $dd0
    done
done


find recomEta*/*/Comb*.root |wc
 
mkdir outcomb; for ii in $(echo  recomEta_TPC1TOF9_GrID*/*/Comb*.root ); do jj=$(echo $ii| tr -s '/' '_'); cp $ii outcomb/$jj ;done

grep grstat1file7 recomEta_TPC1TOF9_GrID10*/*/see.log |wc
grep grstat1file5 recomEta_TPC1TOF9_GrID10*/*/see.log |wc
grep grstat1file2 recomEta_TPC1TOF9_GrID10*/*/see.log |wc

##################################################

1.12 compare any two sets of final results, just an example

ln -s $TCF_PATH/SysUtils/fastComp

t1=reg0
t2=reg1

for aa in $(echo 10 13)
do
    for bb in $(echo Incl IDFF)
    do
        for cc in $(echo c000_010 c010_040 c040_100)
        do
            f1=$(echo $t1/*$aa*$bb*$cc*)
            f2=$(echo $t2/*$aa*$bb*$cc*)
            ./fastComp $f1 $f2  $t1\-$t2-$aa\-$bb\-$cc
        done
    done
done

#or

a=oldn2; b=newn2; c=10; d=PP; ./fastComp $a/outgrsys_id$c\.root $b/outgrsys_id$c\.root $a\_$b\_$d\-$c\- > see_$a\_$b\_$c\_$d.log

#or last string xtit;ytit_header_legend1_legend2_lasttag"
./fastComp old/out10.root new/out10.root  "pT (GeV/c);fraction_c000_old_new_-10-"

#or
yerrfac=1
dodraw(){
for ii in $(echo */)
do
    echo $ii
    cd $ii
    
    ln -s $TCF_PATH/SysUtils/fastComp

    tags=$(echo */ | tr -s '/' ' ' | tr -s '\n ' '_')

    id=10; ./fastComp */*$id*.root "pT;fraction_$(echo $ii | tr -s '/' '_')${tags}-${id}-" $yerrfac
    id=13; ./fastComp */*$id*.root "pT;ratio_$(echo $ii | tr -s '/' '_')${tags}-${id}-" $yerrfac

    cd -
done
}
#or
dogo(){
d0=$(pwd); for ii in $cc;  do dir=$aa$ii/$gg;mkdir $dir;  cd $dir; for jj in $(echo 10 13); do  ln -s $dt/*ID$jj*$bb*$dd*$ii* out$jj.root; done; cd $d0;done
#d0=$(pwd); for ii in $cc;  do dir=$aa$ii/$gg;mkdir $dir;  cd $dir; for jj in $(echo 10 13); do  ln -s $dt/*$bb*$ii*Sys$jj/out*.root out$jj.root; done; cd $d0;done
}

dt=../../../outcomb
gg=2new
aa=PP; bb=histRecTHnIDFF; cc=$(echo 5-10 10-15 15-20); dogo
aa=ppb; bb=_THnIDFF; cc=$(echo c000 c010 c040); dogo
aa=incl; bb=_THnIncl; cc=$(echo c000 c010 c040); dogo
 

dt=/data/t2k/xlu/software/TCFlight/test/save/OLDppb
gg=1old
aa=ppb; bb=IDFF; cc=$(echo c000 c010 c040); dogo
aa=incl; bb=Incl; cc=$(echo c000 c010 c040); dogo

dt=/data/t2k/xlu/software/TCFlight/test/save/GSIJET
gg=1old
aa=PP; bb=JPT; cc=$(echo 5-10 10-15 15-20); dogo

dodraw


#or

dt=/data/t2k/xlu/software/TCFlight/test/save/P1finish/Beta22/outcomb/
cc=5-10; gg=A${cc}; dogo
cc=10-15; gg=B${cc}; dogo
cc=15-20; gg=C${cc}; dogo

dt=/data/t2k/xlu/software/TCFlight/test/P2finish/outcomb
cc=c040; gg=D${cc}; dogo
cc=c010; gg=E${cc}; dogo
cc=c000; gg=F${cc}; dogo

#or, for comparing different jetpt and centralities, namely only 1 cc, but different bb
aa=ppb; dd=c040;cc=coh; bb=Incl; gg=1${bb}${dd};dogo

#or
for ii in $(echo *ID13*); do jj=ID13_fit_$ii; ln -s $ii $jj;done
for ii in $(echo *ID10*); do jj=ID10_fit_$ii; ln -s $ii $jj;done
for ii in $(echo *ID63*); do jj=ID13_true_$ii; ln -s $ii $jj;done
for ii in $(echo *ID60*); do jj=ID10_true_$ii; ln -s $ii $jj;done

gg=1true; aa=PP; bb=true; cc=$(echo JPT{5-10,10-15,15-20}); dogo
gg=2fit; bb=fit; dogo

#or
#dt=/data/t2k/xlu/software/TCFlight/test/save/GSIJET
dt=/data/t2k/xlu/software/TCFlight/test/save/P1finish/outcomb
aa=all; cc=root; 
dd=10-15; bb=IDFF; gg=0${bb}${dd};dogo

#dt=/data/t2k/xlu/software/TCFlight/test/save/pPb_P9S0S1/outcomb/
dt=/data/t2k/xlu/software/TCFlight/test/save/pPb_P9S0S5_incl20GeV/outcomb/
aa=all; cc=root; 
dd=c040; bb=IDFF; gg=1${bb}${dd};dogo
dd=c010; bb=IDFF; gg=2${bb}${dd};dogo
dd=c000; bb=IDFF; gg=3${bb}${dd};dogo
dd=c040; bb=Incl; gg=4${bb}${dd};dogo
dd=c010; bb=Incl; gg=5${bb}${dd};dogo
dd=c000; bb=Incl; gg=6${bb}${dd};dogo

#or

dt=/data/t2k/xlu/software/TCFlight/test/save/S5finish/ETUA3/; gg=A610; aa=c000; bb=$aa; cc=$(echo E{T,U}A3); dogo; dt=/data/t2k/xlu/software/TCFlight/test/save/T0finish/ETUA3; gg=B1418; dogo;
dt=/data/t2k/xlu/software/TCFlight/test/save/S5finish/ETUA3/; gg=A610; aa=c010; bb=$aa; cc=$(echo E{T,U}A3); dogo; dt=/data/t2k/xlu/software/TCFlight/test/save/T0finish/ETUA3; gg=B1418; dogo;
dt=/data/t2k/xlu/software/TCFlight/test/save/S5finish/ETUA3/; gg=A610; aa=c040; bb=$aa; cc=$(echo E{T,U}A3); dogo; dt=/data/t2k/xlu/software/TCFlight/test/save/T0finish/ETUA3; gg=B1418; dogo



