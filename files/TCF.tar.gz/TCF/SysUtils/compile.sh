trap "exit 1" TERM
export TOP_PID=$$

TCF_exe_mk.sh drawpar
TCF_exe_mk.sh getGrSys

TCF_exe_mk.sh drawBiCorrection

TCF_lib_mk.sh style
TCF_exe_mk.sh drawMeanGrSys01.C "-lstyle"
TCF_exe_mk.sh getCombFrac.C "-lstyle"

TCF_exe_mk.sh fastComp "-lstyle"


