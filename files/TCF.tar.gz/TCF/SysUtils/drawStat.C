{
  int col=kBlue;
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_ETA0_p0d0_0d2_MC0/hist.root");
  horiginalyield->SetTitle("Blue: c000-010, Red: c010-040, Green: c040-100; log10(p); counts");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw(); 
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_EUA0_n0d2_0d0_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_ETA1_p0d2_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_EUA1_n0d4_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_ETA2_p0d4_0d6_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_EUA2_n0d6_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");

  col=kRed;
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_ETA0_p0d0_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_EUA0_n0d2_0d0_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_ETA1_p0d2_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_EUA1_n0d4_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_ETA2_p0d4_0d6_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_EUA2_n0d6_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");

  col=kGreen;
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_ETA0_p0d0_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_EUA0_n0d2_0d0_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_ETA1_p0d2_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_EUA1_n0d4_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_ETA2_p0d4_0d6_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIDFF_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_EUA2_n0d6_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");

  gPad->SetLogy();

  //======================

  Int_t col=kBlue;
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_ETA0_p0d0_0d2_MC0/hist.root");
  horiginalyield->SetTitle("Blue: c000-010, Red: c010-040, Green: c040-100; log10(p); counts");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw(); 
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_EUA0_n0d2_0d0_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_ETA1_p0d2_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_EUA1_n0d4_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_ETA2_p0d4_0d6_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c000_010_EUA2_n0d6_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");

  col=kRed;
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_ETA0_p0d0_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_EUA0_n0d2_0d0_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_ETA1_p0d2_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_EUA1_n0d4_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_ETA2_p0d4_0d6_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c010_040_EUA2_n0d6_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");

  col=kGreen;
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_ETA0_p0d0_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_EUA0_n0d2_0d0_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_ETA1_p0d2_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_EUA1_n0d4_0d2_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_ETA2_p0d4_0d6_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");
  ff=new TFile("JET_pPb_DATA_8etas_12GeV/_home_luxi_tmp_TCF_THnIncl_V0A_trkPtLT12GeV_TPC1TOF9_c040_100_EUA2_n0d6_0d4_MC0/hist.root");
  horiginalyield->SetMarkerColor(col); horiginalyield->SetLineColor(col); horiginalyield->Draw("same");

  gPad->SetLogy();

}
