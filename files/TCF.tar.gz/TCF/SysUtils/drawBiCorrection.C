#include "headers.hh"
#include "SysUtils.h"

void drawBiCorrection(const TString tit, const Int_t bt)
{
  TCanvas *c1=new TCanvas;
  gPad->SetLogy(0);
  gStyle->SetOptStat("enoumr");

  TString tag;
  TString pwd=gSystem->pwd();
  if(pwd.Contains("MCjet"))
    tag="MC";
  else if(pwd.Contains("datajet") ||  pwd.Contains("LEGO_90_91"))
    tag="data";
  else{
    //printf("wrong pwd %s\n", pwd.Data()); exit(1);
    tag="x_data";
  }

  tag+=tit;

  //TH1D *hh=new TH1D("hh","",200,-0.03, 0.03);
  TH1D *hh=new TH1D("hh","",200,-0.05, 0.05);

  TChain *ch=SysUtils::InputFiles(Form("allgood%d.log", bt),"tree");
  ch->Draw("bb7>>hh");
  hh->SetTitle(tag+";C_{p};counts");
  c1->Print(tag+Form("%d.eps", bt));
}

int main(int argc, char* argv[])
{
  for(int ii=0; ii<argc; ii++){
    printf("%d: %s\n", ii, argv[ii]);
  }

  if(argc!=3){
    printf("argv!=3\n"); return 1;
  }

  drawBiCorrection(argv[1], atoi(argv[2]));

  return 0;
}
