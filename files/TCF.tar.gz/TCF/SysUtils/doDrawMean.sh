

ln -s ../Sys01/in.log

ln -s $TCF_PATH/SysUtils/getGrSys

for ii in $(echo 00 01 02)
do
#with checkCp=0
    ./getGrSys in.log $ii 0 0 > tmp$ii
done

grep frac tmp*

dd=$(echo ../XB* | tr -s ' ' '\n' | head -n 1 )
ln -s $dd/hist.root 

rm -f *.eps

./drawMeanGrSys01 > seetmp



