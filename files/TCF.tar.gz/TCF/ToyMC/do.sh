res=0.05

if [ $# == 1 ]
then 
    res=$1
fi


for ii in $(echo aleph lund mBB)
do
    dir=$ii\_res$res

    mkdir -p $dir
    cd $dir
    ../genhist $res > see.log
    cd -
done
